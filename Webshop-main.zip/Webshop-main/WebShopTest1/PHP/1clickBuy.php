<?php 

session_start();
if(isset($_SESSION['login'])){
if($_SESSION['login']==111)
    {
        if(isset($_SESSION['UserID'])){$iUserID = $_SESSION['UserID'];}
    
    }}else{$_SESSION['login'] = 000;}
    
    $OldOrderID = "";

    if(isset($_POST['OrderID'])){
        $OldOrderID = $_POST['OrderID'];
    }


    include 'dbsettings.php';


    /*if (isset($_POST['versand'])) 
	{
		$versand=$_POST['versand'];
        if($versand=="DPD") {
            $versandPreis = 5;
        } elseif($versand=="DHL") {
            $versandPreis = 10;
        } elseif($versand=="DHL Express") {
            $versandPreis = 24;
        }
        $finalPrice += $versandPreis;
	}*/

    function generateRandomString($length = 11) {
        $characters = '0123456789abcdefghijklmnopqrs092u3tuvwxyzaskdhfhf9882323ABCDEFGHIJKLMNksadf9044OPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    $OrderID = generateRandomString();
    

    $conn = new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM `Order` WHERE OrderID = :orderID";
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':orderID', $OldOrderID);
    $stmt->execute();
    foreach($stmt as $row){
        $ProductID = $row['ProductID'];
        //echo $ProductID;
        $Amount = $row['Amount'];
        $versand = $row['Versand'];
        $finalSum = $row['finalSum'];

        $sql= "INSERT INTO `Order` (OrderID, UserID, productID, Amount, Versand, finalSum) VALUES (?,?,?,?,?,?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$OrderID,$iUserID,$ProductID,$Amount,$versand,$finalSum]);
    }
    
    

    //$sFirstname=$conn->query("SELECT firstname FROM USER WHERE userID=$iUserID");
    //$sLastname=$conn->query("SELECT lastname FROM USER WHERE userID=$iUserID");


    //$orderData= $conn->query("SELECT  product.name, order.amount  FROM product, order WHERE orderID=$orderID AND order.productID=product.productID");

    //$mailMessage = 'Hello, '.$sFirstName.' '.$sLastName.' thank you for your order: \n'.$orderID.'\n'.$orderData.'\n'.$versand.': '.$versandPreis.'\n'.'Gesamtsumme: '.$finalPrice;

    //$sUserName = $conn->query("SELECT email FROM user WHERE userID=$iUserID");

    //include ' ..\vendor\phpmailer\phpmailer\examples\gmail_xoauth.php';
    header("Location: profile.php");
?>