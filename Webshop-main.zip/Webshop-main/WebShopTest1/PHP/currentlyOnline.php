<?php
    if (isset ($_GET["numOn"]))
    {
    include 'dbsettings.php';
    $conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "SELECT * FROM userOnline WHERE ID=0" ;
    $result = $conn->query($sql); 
    foreach($result as $row) {
        $numOnline = $row['numOnline'];
    }
    echo($numOnline);
    }
?>