<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php
    include 'headimport.php';
    ?>
  <title>Document</title>
</head>

<body class="p-3 m-0 border-0 bd-example " id="bd">
<h1>Thank you for your order!</h1>
</body>

</html>