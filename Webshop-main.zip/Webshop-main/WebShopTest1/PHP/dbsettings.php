<?php

    $dbDatabasename='webshopdatabase';
    $dbLoginUsername='root';    
    $dbPassword=''; 

?>