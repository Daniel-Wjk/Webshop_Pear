<?php
session_start();
if(!isset($_SESSION['login'])){
    $_SESSION['login'] = 000;}
if($_SESSION['login']!=111)
    {
        header("Location: home.php");  
    }
    if($_SESSION['login']==111)
    {
        if(isset($_SESSION['UserID'])){$iUserID = $_SESSION['UserID'];}
        if(isset($_SESSION['firstname'])){$sFirstname = $_SESSION['firstname'];}
        if(isset($_SESSION['lastname'])){$sLastname = $_SESSION['lastname'];}
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include 'headimport.php';
    ?>
    <title>Document</title>
</head>

<body class="p-3 m-0 border-0 bd-example " id="bd">
    <div class="container">
       
        <div class="row">

            <div class="col"></div>
            <div class="col color2 rounded">
                <div class="text-center mt-3">

                    <h3>Edit Profile</h3> <img src="../IMGS/user-gdb454317d_1280.png" class="rounded w-25" alt="...">
                </div>

                <form method="POST" class="mx-1" action="editProfileCheck.php">

                    <div class="mb-3">
                        <label for="firstname" class="form-label">Firstname</label>
                        <input type="Text" placeholder=<?php echo($sFirstname); ?> class="form-control" id="firstname" name="firstname" value="">
                    </div>
                    <div class="mb-3">
                        <label for="lastname" class="form-label">Lastname</label>
                        <input type="Text" placeholder=<?php echo($sLastname); ?> class="form-control" id="lastname" name="lastname" value="">
                    </div>
                    <div class="mb-3">
                        <label for="currentPassword" class="form-label">Current Password</label>
                        <input type="password" class="form-control" id="currentPassword" name="currentPassword" value="">
                    </div>
                    <div class="mb-3">
                        <label for="newPassword" class="form-label">New Password</label>
                        <input type="password" class="form-control" id="newPassword" name="newPassword" value="">
                    </div>
                    <div class="mb-3">
                        <label for="newPasswordConfirm" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="newPasswordConfirm" name="newPasswordConfirm" value="">
                    </div>
                    <button type="submit" class="btn btn-primary mb-2">Save Changes</button>
                </form>
                 
            </div>
            <div class="col"></div>
        </div>

    </div>
    <?php
        include 'footimport.php';
    ?>
</body>

</html>