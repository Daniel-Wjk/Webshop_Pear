
<script src="jquery.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
    setInterval(function()
    {
        $.get("currentlyOnline.php",
        { numOn:1*new Date()},
        function(daten)
        {
            $('#currentlyOnline').html(daten);
        });
    },1000);
});
</script>