<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">    
    <?php
    include 'headimport.php';
    ?>
    <title>Document</title>
</head>
<body class="m-0 border-0 bd-example" id="bd">
    <div class="container  mt-5 d-flex justify-content-center">
        <div class="card">
            <div class="card-body">
                <h4>Forgot Password?</h4>
                <p>No problem.</p>
                <p>Please Enter your Email. You will recive a new Password via E-Mail.</p>
                <form action="forgotPasswordCheck.php" method='POST'>
                    <div class="mb-3">
                        <label for="emailforgotpassword" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="emailforgotpassword" name="emailforgotpassword" value='' placeholder="name@example.com">
                      </div>
                    <button type="submit" class="btn btn-primary mb-2">Send new Password.</button>
                </form>

            </div>
        </div>
    </div>
</body>
</html>