<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">    
    <?php
    include 'headimport.php';
    ?>
    <title>Document</title>
</head>
<body class="m-0 border-0 bd-example" id="bd">
    <div class="container  mt-5 d-flex justify-content-center">
        <div class="card">
            <div class="card-body">
                <h4>Your Login was a success!</h4>
                <p>Since you forgot the Password.</p>
                <p>Please change the Password to your Preference!</p>
                <form action="checkFirstLogin.php" method="POST">
                    <div class="mb-3">
                        <label for="currentPassword" class="form-label">Current Password</label>
                        <input type="password" class="form-control" id="currentPassword" name="currentPassword" value="">
                    </div>
                    <div class="mb-3">
                        <label for="newPassword" class="form-label">New Password</label>
                        <input type="password" class="form-control" id="newPassword" name="newPassword" value="">
                    </div>
                    <div class="mb-3">
                        <label for="newPasswordConfirm" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="newPasswordConfirm" name="newPasswordConfirm" value="">
                    </div>
                    <button type="submit" class="btn btn-primary mb-2">Save Changes</button>
                </form>

            </div>
        </div>
    </div>
</body>
</html>