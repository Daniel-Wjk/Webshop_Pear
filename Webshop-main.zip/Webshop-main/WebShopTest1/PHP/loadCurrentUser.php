<?php
    $sql = "SELECT numOnline FROM userOnline";
    $result = $conn->query($sql);

    echo "<p>";
    echo $result;
    echo "</p>";
?>