
<div class="container sticky-top" style="background-color: rgb(119, 184, 241);">
<nav class="navbar navbar-expand-lg " id="navigation">
    <div class="container-fluid ">
        <a href="home.php" class="navbar-brand "><img src="../imgs/pear1.png" style="height: 50px" alt=""> Pear</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="home.php">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="product_overwiew.php" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Products
                    </a>
                    <ul class="dropdown-menu">
                        <li><form action="product_overview.php" method="post"><input type="hidden" name="SortMethod" value="TYP"> <input type="hidden" name="SortedBy" value="SmartPhone"><button class="btn" type="submit">SmartPhones</button></form></li>
                        <li><form action="product_overview.php" method="post"><input type="hidden" name="SortMethod" value="TYP"> <input type="hidden" name="SortedBy" value="PC"><button class="btn" type="submit">PCs</button></form></li>
                        <li><form action="product_overview.php" method="post"><input type="hidden" name="SortMethod" value="TYP"> <input type="hidden" name="SortedBy" value="Equipment"><button class="btn" type="submit">Equipment</button></form></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><form action="product_overview.php" method="post"><input type="hidden" name="SortMethod" value="TYP"><input type="hidden" name="SortedBy" value="ALL"><button class="btn" type="submit">All Products</button></form></li>

                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="support.php">Support</a>
                </li>
                
                
            </ul>
        </div>
    </div>
    <div class=" d-flex">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <?php
                include 'dbsettings.php';
                $conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
                if($_SESSION['login']==111){
                    $iUserID = "";
                    if(isset($_SESSION['UserID'])){
                        $iUserID = $_SESSION['UserID'];
                    }
                    
                    $sql="SELECT * FROM Shoppingcart WHERE UserID = ".$iUserID." ";
                    $ergebnis = $conn->query($sql);
                    $AmountInSchoppingcart = 0;
                    foreach($ergebnis as $row){
                        $AmountInSchoppingcart = $AmountInSchoppingcart + $row['Amount'];
                    }
                    echo '
                    <li class="nav-item dropdown d-flex"><a id="currentUserNumber" class="nav-link">Currently Online
                    <span
                    class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" value="" id="currentlyOnline">
                    </span></a></li>
                    <li class="nav-item dropdown  d-flex">
                    <a class="nav-link" href="shoppingcart.php" class="btn btn-primary">
                    Shoppingcart
                        <span
                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        '.$AmountInSchoppingcart.'
                        </span>
                    </a>
                    </li>';
                }
            ?>
            
            <li class="nav-item dropdown  d-flex">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                    aria-expanded="false">
                    <i class="fa-solid fa-user"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <?php 

                    if($_SESSION['login']!=111){
                        echo '<li><a class="dropdown-item" href="login.php">Login</a></li> 
                        <li>
                        <hr class="dropdown-divider">
                        </li> 
                        <li><a class="dropdown-item" href="registration.php">Registration</a></li>';
                    }
                    if($_SESSION['login']==111){

                        echo '
                    <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                    <li><a class="dropdown-item" href="editprofile.php">Edit Profile</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    ';
                    }
                    ?>
                </ul>
            </li>
        </ul>

    </div>
    <br>
</nav>
</div>



