<?php
session_start();
if(isset($_SESSION['login'])){
if($_SESSION['login']==111)
    {
        if(isset($_SESSION['UserID'])){$iUserID = $_SESSION['UserID'];}
        if(isset($_SESSION['firstname'])){$sFirstname = $_SESSION['firstname'];}
        if(isset($_SESSION['lastname'])){$sLastname = $_SESSION['lastname'];}
    
    }}else{$_SESSION['login'] = 000;
        header("Location: home.php");}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include 'headimport.php';
    ?>
    <title>Document</title>
</head>

<body class="m-0 border-0 bd-example" id="bd">


    <?php
        include 'navimport.php';
    ?>

    <div class="container color1 d-flex justify-content-center">
        <div class="card m-3 align-items-center ">
            <div class="card-body m-3">

                <h2 class="card-title"><i class="fa-solid fa-user"></i><?php echo ' '.$sLastname.' '.$sFirstname; ?></h2>
                <p class="card-text">Hear you can check your last orders and reorder them with just one mouse button.
                </p>
                <br>
                <p class="card-text">These are your last Orders</p>
                <div class="card m-3">
                    <?php
                    $finalSum=0;
                    $versand=0;
                    include 'dbsettings.php';
                    $conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $sql = "SELECT orderID FROM `Order` WHERE userID = :userID GROUP BY orderID";
                    $stmt = $conn->prepare($sql);
                    $stmt->bindValue(':userID', $iUserID);
                    $stmt->execute();
                    foreach($stmt as $row){
                        $iOrderID = $row['orderID'];
                        $sql = "SELECT finalSum FROM `Order` WHERE orderID = :orderID";
                        $stmt = $conn->prepare($sql);
                        $stmt->bindValue(':orderID', $iOrderID);
                        $stmt->execute();
                        
                        foreach($stmt as $row){
                            $finalSum=$row['finalSum'];
                        }
                        $sql = "SELECT versand FROM `Order` WHERE orderID = :orderID";
                        $stmt = $conn->prepare($sql);
                        $stmt->bindValue(':orderID', $iOrderID);
                        $stmt->execute();
                        
                        foreach($stmt as $row){
                            $versand=$row['versand'];
                        }

                        echo '<div>
                            <table class="table">
                            <thead class="tabel">
                                Order Nr: '.$iOrderID.' | 
                                Shipping Option: '.$versand. '
                            </thead>
                            <thead>
                                <tr>
                                    <th scope="col">Product Name</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">Product ID</th>
                                </tr>
                            </thead>';

                        $sql = "SELECT * FROM `Order` WHERE orderID = :orderID";
                        $stmt = $conn->prepare($sql);
                        $stmt->bindValue(':orderID', $iOrderID);
                        $stmt->execute();

                        foreach($stmt as $row) {
                            $iProductID = $row['ProductID'];
                            $sql = "SELECT * FROM `Product` WHERE productID = :productID";
                            $stmt_product = $conn->prepare($sql);
                            $stmt_product->bindValue(':productID', $iProductID);
                            $stmt_product->execute();
                        
                            $productName = "";
                            foreach($stmt_product as $product_row) {
                                $productName = $product_row['Name'];
                            }
                        
                            $iAmount = $row['Amount'];
                        
                            echo '
                                <tbody>
                                    <tr>
                                        <th>'.$productName.'</th>
                                        <td>'.$iAmount.'</td>
                                        <td>'.$iProductID.'</td>
                                    </tr>
                                </tbody>
                            ';
                        }
                        echo '
                        <tbody>
                        <form action="1clickBuy.php" method="POST">
                        <input type="hidden" id="orderId" name="OrderID" value='.$iOrderID.'>
                        <button type="submit" class="btn btn-primary m-3">Buy Again!</button>
                        </form>
                        </tbody>
                        </div>';

                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <?php
        include 'footimport.php';
    ?>
</body>

<?php

?>

</html>