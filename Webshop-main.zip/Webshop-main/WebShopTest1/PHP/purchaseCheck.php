<?php 

session_start();
if(isset($_SESSION['login'])){
if($_SESSION['login']==111)
    {
        if(isset($_SESSION['UserID'])){$iUserID = $_SESSION['UserID'];}
        if(isset($_SESSION['email'])){$sUsername = $_SESSION['email'];}
        if(isset($_SESSION['firstname'])){$sFirstname = $_SESSION['firstname'];}
        if(isset($_SESSION['lastname'])){$sLastname = $_SESSION['lastname'];}
    }}else{$_SESSION['login'] = 000;}

    

    $finalPrice = 0;

    include 'dbsettings.php';

    echo var_dump($_POST);
    $versand="";

    if (isset($_POST['versand'])) 
	{
		$versand=$_POST['versand'];
        if($versand=="DPD") {
            $versandPreis = 5;
        } elseif($versand=="DHL") {
            $versandPreis = 10;
        } elseif($versand=="DHL Express") {
            $versandPreis = 24;
        }
        $finalPrice += $versandPreis;
	}

    function generateRandomString($length = 11) {
        $characters = '0123456789abcdefghijklmnopqrs092u3tuvwxyzaskdhfhf9882323ABCDEFGHIJKLMNksadf9044OPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }



    $conn = new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $orderID = "";
    $OrderVorhanden = 0;
    while($OrderVorhanden == 0) {
        $orderID = generateRandomString();
        $sql_1 = "SELECT COUNT(*) as OrderExists FROM `Order` WHERE OrderID = :value1";
        $stmt = $conn->prepare($sql_1);
        $stmt->bindValue(':value1', $orderID);
        $stmt->execute();
        foreach($stmt as $row){
            $result = $row['OrderExists'];
            if($result == 0){
                $OrderVorhanden = 1;
            }
        }
    }
    echo  $orderID;

    $sql_products = "SELECT ProductID, Amount FROM Shoppingcart WHERE userID = '".$iUserID."'";
    $stmt_products = $conn->query($sql_products);
    $sum = 0;
    foreach($stmt_products as $row) {
    $productID = $row['ProductID'];
    $Amount = $row['Amount'];
    $product_price = "";
    $sql_Price = "SELECT Price FROM Product WHERE ProductID = ".$productID;
    $stmt_Price = $conn->prepare($sql_Price);
    $stmt_Price->execute();
    $row_Price = $stmt_Price->fetch();
    $product_price = $row_Price['Price'];
    if($Amount >= 5) {
        $sum += ($product_price * $Amount) * 0.95;
    } else if($Amount >= 10) {
        $sum += ($product_price * $Amount) * 0.85;
    } else {
        $sum += $product_price * $Amount;
    }
    if(isset($_POST['promo'])) {
        $promocode = $_POST['promo'];
        if($promocode=='promo10') {
            $sum = $sum * 0.9;
        }
    }
    $sql = "INSERT INTO `order` (OrderID, UserID, ProductID, Amount, Versand,finalSum) VALUES (?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$orderID, $iUserID, $productID, $Amount, $versand,$sum]);
    $finalPrice += $sum;
    $sum = 0;  
    
}

    include 'sendOrder.php';
    sendOrderEmail($sUsername, $sLastname, $sFirstname, $orderID, $versand, $finalPrice);

    $sql = "DELETE FROM Shoppingcart";
    $conn->query($sql);
    header("Location: profile.php");
?>


