<?php
$iAmount=0;
$iProductID=0;
$iUserID=0;
$ReturnTo="";
session_start();
if(!isset($_SESSION['login'])){
    $_SESSION['login'] = 000;}
if($_SESSION['login']!=111)
    {
        header("Location: home.php");  
    }
    else{
        $iUserID = $_SESSION['UserID'];
    }

    //echo var_dump($_POST);
    if(isset($_POST['ProductID']))
    {
        $iProductID=$_POST['ProductID'];
    }
    if(isset($_POST['returnTo']))
    {
        $ReturnTo=$_POST['returnTo'];
    }
    
    try
    {
    include 'dbsettings.php';
    $conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM Shoppingcart Where UserID = :value1 AND ProductID = :value2";
                $stmt = $conn->prepare($sql);
                $stmt->bindValue(':value1', $iUserID);
                $stmt->bindValue(':value2', $iProductID);
                $stmt->execute();
                foreach($stmt as $row){
                    $iAmount=$row['Amount'];
                }
    if($iAmount > 1){
        $sql = "UPDATE Shoppingcart SET Amount = Amount - 1 Where UserID = :value1 AND ProductID = :value2";
                $stmt = $conn->prepare($sql);
                $stmt->bindValue(':value1', $iUserID);
                $stmt->bindValue(':value2', $iProductID);
                $stmt->execute();
    }
    elseif($iAmount = 1){
        $sql = "DELETE FROM Shoppingcart Where UserID = ".$iUserID." AND ProductID = ".$iProductID;
        $stmt = $conn->query($sql);
    }
    

    $conn=null;
}
catch(Exception $e)
{
    echo "Fehler: ".$e;
}
if(strcmp($ReturnTo,'product_page.php')===true){
    
    $data = [
        'ProductID' => $iProductID
    ];
    
    $queryString = http_build_query($data); // Convert the data array to a query string
    header('Location: product_page.php?' . $queryString);
}else{
    header('Location: shoppingcart.php');
}
?>