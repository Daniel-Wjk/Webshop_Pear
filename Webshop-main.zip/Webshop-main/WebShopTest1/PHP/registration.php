<?php
session_start();
if(isset($_SESSION['login'])){
if($_SESSION['login']==111)
    {
        if(isset($_SESSION['UserID'])){$iUserID = $_SESSION['UserID'];}
    
    }}else{$_SESSION['login'] = 000;}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php
    include 'headimport.php';
    ?>
</head>

<body class="m-0 border-0 bd-example" id="bd">

    <?php
    include 'navimport.php';
    ?>

    <div class="container">
        <div class="row">
            <br><br>
        </div>
        <div class="row">

            <div class="col"></div>
            <div class="col color2 rounded">
                <div class="text-center mt-3">

                    <h3>Registration</h3> <img src="../IMGS/user-gdb454317d_1280.png" class="rounded w-25" alt="...">
                </div>

                <form  class="mx-1" action="checkRegister.php" method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="username" name="username" value="" aria-describedby="emailHelp">
                        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                    </div>
                    <div class="mb-3">
                        <label for="firstname" class="form-label">First Name</label>
                        <input type="Text" class="form-control" id="firstname" name="firstname" value="">
                    </div>
                    <div class="mb-3">
                        <label for="lastname" class="form-label">Last Name</label>
                        <input type="Text" class="form-control" id="lastname" name="lastname" value="">
                    </div>
                    <button id="register" type="submit" class="btn btn-primary mb-2">Register</button>
                </form>

                <p class="mb-3" id="hiddentext">Username requieres "@".</p>

                <br><br>


            </div>
            <div class="col"></div>
        </div>

    </div>
    <script>
        
        $(document).ready(function()
        {
            setInterval(function()
            {
                /*if((($_POST['username'] !== NULL) && (str_contains($_POST['username'], "@"))))*/
                if(document.getElementById("username").value.includes("@")) {
                    console.log("working");
                    document.getElementById("hiddentext").style.visibility="hidden";
                } else {
                    document.getElementById("hiddentext").style.visibility="visible";
                };
            },1000);
        });
  

        //$('#register').on('click',function(){
        //    Swal.fire( 'Great, almost done!', 'Please check your emails and start your first Login.', 'success' );
        //});
    </script>
</body>

</html>