<?php
session_start();
if(!isset($_SESSION['login'])){
    $_SESSION['login'] = 000;}
if($_SESSION['login']!=111)
    {
        header("Location: home.php");  
    }else{
        $iUserID = $_SESSION['UserID'];
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include 'headimport.php';
    ?>
    <title>Document</title>
</head>

<body class="m-0 border-0 bd-example " id="bd">

    <?php
        include 'navimport.php';
    ?>
    <div class="container color1 d-flex align-items-center">

        <div class="row m-3">
            <h2>
                Shoppingcart
            </h2> 
            <p>Hello, you currently have <?php echo $AmountInSchoppingcart; ?> Products in your shoppingcart!</p>
            <div class="row d-flex justify-content-center">
                <div class="card w-50 m-3">
                    <ul class="list-group list-group-flush">
                        <?PHP
                            include 'dbsettings.php';
                            $conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                            $sql="SELECT * FROM Shoppingcart WHERE UserID = ".$iUserID;
                            $ergebnis =  $conn->query($sql);
                            $iSumme = 0.00;
                            $iSumme += $iSumme;
                            //$iSumme = number_format($iSumme, 2);

                            foreach($ergebnis as $row){
                                $iProductID = $row['ProductID'];
                                $iAmount = $row['Amount'];
                                $sql1 = "SELECT * FROM Product WHERE ProductID = ".$iProductID;
                                $ergebnis1 =  $conn->query($sql1);
                                foreach ($ergebnis1 as $row) {
                                    $sTYP = $row['TYP'];
                                    $sName = $row['Name'];
                                    $sIMGSrc = $row['Img'];
                                    $sDiscription = $row['ProductDescription'];
                                    $fPrice = $row['Price'];
                                    $sInformation = $row['ProductInfos'];
                                }
                                $Discount = 0.00;
                                if($iAmount > 4 && $iAmount < 10){
                                    $Discount = 0.05;
                                }elseif($iAmount > 9){
                                    $Discount = 0.15;
                                }
                                $iTotal = ($iAmount*$fPrice);
                                $iTotal = $iTotal - ($iTotal * $Discount);
                                //$iTotal = number_format($iTotal, 2);
                                $Discount = $Discount * 100;
                                $iSumme += $iTotal;
                                //$iSumme = number_format($iSumme, 2);

                                echo '<li class="list-group-item">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="../IMGS/'.$sIMGSrc.'" class="img-fluid rounded-start " alt="...">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body">
                                            <h5 class="card-title">'.$sName.'</h5>
                                            <p class="card-text">'.$fPrice.' €</p>
                                            <div class="row">
                                            <form action="reduceAmount.php" method="Post"> <input type="hidden" name="ProductID" value="'.$iProductID.'"><input type="hidden" name="returnTo" value="shoppingcart.php"> <button class="btn btn-primary" type="submit" ID="reduceAmount">-</button></form> '.$iAmount.' <form action="increaseAmount.php" method="Post"> <input type="hidden" name="ProductID" value="'.$iProductID.'"><input type="hidden" name="returnTo" value="shoppingcart.php"><button class="btn btn-primary" type="submit" ID="increaseAmount">+</button></form>
                                            </div>
                                            <div>
                                                Discount: '.$Discount.'% <br>
                                                Cost: '.$iTotal.' €
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </li>';
                            }
                        ?>

                    <li class="list-group-item">Total Cost: <?php echo($iSumme); ?> €</li>        
                    </ul>
                    
                        <form action="purchase.php" method="POST">
                            <input type="hidden" name="TotalCost" value=<?php echo($iSumme); ?>>
                            <button type="submit" class="btn btn-primary">Buy</button>
                        </form>    
                    
                </div>
                
            </div>
            
        </div>
    </div>
    </div>
    <?php
        include 'footimport.php';
    ?>
</body>

</html>