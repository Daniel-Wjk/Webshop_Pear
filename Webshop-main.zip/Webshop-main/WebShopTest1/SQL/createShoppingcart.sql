CREATE TABLE `Shoppingcart`(
    `UserID` int(11),
    `ProductID` int(11),
    `Amount` int DEFAULT 1,
    PRIMARY KEY (`UserID`,`ProductID`)
)