CREATE TABLE `Order`(
    `OrderID` char(11),
    `UserID` int(11),
    `ProductID` int(11),
    `Amount` int(11) NOT NULL DEFAULT 1,
    `time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `Versand` varchar(50),
    `finalSum` float(2),
    PRIMARY KEY (`OrderID`,`UserID`,`ProductID`),
    FOREIGN KEY (`ProductID`) REFERENCES Product(`ProductID`),
    FOREIGN KEY (`UserID`) REFERENCES User(`UserID`),
    CHECK (`Amount` >= 1)
)