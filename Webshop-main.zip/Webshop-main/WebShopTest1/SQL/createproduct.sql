CREATE TABLE `Product`(
    `ProductID` int(10) NOT NULL AUTO_INCREMENT,
    `TYP` varchar(50) NOT NULL,
    `Name` varchar(100) NOT NULL,
    `Price` float(2) NOT NULL,
    `Img` varchar(300),
    `ProductDescription` text(10000),
    `ProductInfos` text(10000),
    `Stock` int(10),
    PRIMARY KEY (`ProductID`),
    CHECK (`TYP` IN ('SmartPhone' , 'PC' , 'Equipment'))
)