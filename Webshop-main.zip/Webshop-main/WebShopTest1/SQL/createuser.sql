CREATE TABLE `User` (
    `UserID` int(10) NOT NULL AUTO_INCREMENT,
    `firstname` varchar(50) NOT NULL,
    `lastname` varchar(50) NOT NULL,
    `email` varchar(50) NOT NULL,
    `Password` varchar(500) NOT NULL,
    `Google2FSecret` varchar(50) NOT NULL,
    `LoginStatus` int NOT NULL DEFAULT 0,
    `OnlineStatus` boolean NOT NULL,
    `LastOnline` DATETIME,
    `Resolution` varchar(50),
    PRIMARY KEY (`UserID`),
    CHECK (`LoginStatus` IN (0 , 1 , 2))
)