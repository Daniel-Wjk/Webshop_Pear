INSERT INTO `product` (`TYP`,`Name`,`Price`,`IMG`,`ProductDescription`,`ProductInfos`,`Stock`) VALUES
('SmartPhone','IPhone14 PRO', 1299 , 'iphone14pro.jpg','The Iphone 14 PRO is the newest IPhone on the market and is uncompareable with any Other. There is no reason to not buy one!','6 Core CPU A16 Bionic Chip',1000),
('SmartPhone','IPhone14', 999 , 'iphone14.jpg','The Iphone 14 is a very Modern Phone. Buy It if you do not have money for a IPhone 14 Pro! ','5 Core CPU A15 Bionic Chip',1000),
('SmartPhone','IPhone13', 799 , 'iphone13.jpg','The Iphone 13 is a bit older then the IPhone 14 Series but also not bad.','4 Core CPU A15 Bionic Chip',1000),
('SmartPhone','IPhone SE', 549 , 'iphonese.jpg','No money to buy the other SmartPhones from Apple. No problem the IPhone SE was made just for you!','4 Core CPU A15 Bionic Chip',1000),
('PC','Mac Studio', 2399 , 'macstudio.jpg','To much money and dont like windows PCs? Then buy the Mac Studio!','12 Core CPU M2 MAX Bionic Chip',1000),
('PC','MacBook Pro', 2399 , 'macbookpro.jpg','To much money and dont like windows Desktops? Then buy the MacBook Pro!','12 Core CPU M2 MAX Bionic Chip',1000),
('PC','IMac', 1549 , 'imac.jpg','Want to waste your money and buy everything from Apple? Then also buy this one.','8 Core CPU M1 Bionic Chip',1000),
('Equipment','Apple Watch Ultra', 999 , 'applewatchultra.jpg','You have enough money to invest into a Rolex but want to waste it intsed? Buy the Apple Watch Ultra','Dual Core S8 Chip',1000),
('Equipment','AirPods Pro 2', 299 , 'airpodspro2.jpg','You do not want to hear you surroundings and also want to flex? Buy the AirPods Pro 2','H1 Headset Chip',1000),
('Equipment','AirPods Max', 629 , 'airpodsmax.jpg','You do not want to hear you surroundings, want to flex and dont like Inear headset? Buy the AirPods Max!','H1 Headset Chip',1000);

