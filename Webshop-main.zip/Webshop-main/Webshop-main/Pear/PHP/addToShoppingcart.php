<?php
session_start();
if(!isset($_SESSION['login'])){
    $_SESSION['login'] = 000;}
if($_SESSION['login']!=111)
    {
        header("Location: home.php");  
    }
    else{
        $iUserID = $_SESSION['UserID'];
    }

    //echo var_dump($_POST);
    if(isset($_POST['ProductID']))
    {
        $iProductID=$_POST['ProductID'];
    }
    try
    {
    include 'dbsettings.php';
    $conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "INSERT INTO Shoppingcart (UserID, ProductID) VALUES (?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$iUserID, $iProductID]);

    $conn=null;
}
catch(Exception $e)
{
    echo "Fehler: ".$e;
}
$data = [
    'ProductID' => $iProductID
];

$queryString = http_build_query($data); // Convert the data array to a query string

header('Location: product_page.php?' . $queryString);
?>
