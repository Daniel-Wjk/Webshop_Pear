<?php
//session_start();
include 'generatePassword.php';

$sUsername="";
$sFirstname="";
$sLastname="";
$bRegisterSuccess = false;

//str_contains($_POST['username'] , "@")
if (isset($_POST['username'])) 
	{
		$sUsername=$_POST['username'];
	}
if (isset($_POST['firstname'])) 
	{
		$sFirstname=$_POST['firstname'];
	}
if (isset($_POST['lastname'])) 
	{
		$sLastname=$_POST['lastname'];
	}



//try {
    include 'dbsettings.php';

    $conn = new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $usernamesql=$conn->query("SELECT count(*) as countresult FROM user WHERE email='".$sUsername."'");

    foreach($usernamesql as $row) {
        if(!($row['countresult'] > 0))
        {   

        $password = generateRandomPassword(10);
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        require_once '../extern/google_auth/PHPGangsta/GoogleAuthenticator.php';
        $ga = new PHPGangsta_GoogleAuthenticator();
        $secret = $ga->createSecret();
        $sql = "INSERT INTO user (firstname, lastname, email, Password, Google2FSecret) VALUES (?,?,?,?,?)";
        $stmt = $conn->prepare($sql);
        $stmt = $stmt->execute([$sFirstname, $sLastname,$sUsername, $hashed_password,$secret]);
        include 'sendRegistration.php';
        sendRegistrationEmail($sUsername, $sLastname, $password, $sFirstname, $secret);
        $bRegisterSuccess = true;
        }
    }


if($bRegisterSuccess == true){
    header("Location: login.php");
}else{
    header("Location: registration.php");
} 

?>  

