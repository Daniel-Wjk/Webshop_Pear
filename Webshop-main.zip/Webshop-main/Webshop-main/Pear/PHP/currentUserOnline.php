<script>
        
        $(document).ready(function()
        {
            setInterval(function()
            {
              $("#currentUserNumber").load(loadCurrentUser.php);
                
            },1000);
        });
</script>