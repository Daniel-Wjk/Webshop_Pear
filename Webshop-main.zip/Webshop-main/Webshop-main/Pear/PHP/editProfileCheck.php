<?php
session_start();
if(!isset($_SESSION['login'])){
    $_SESSION['login'] = 000;}
if($_SESSION['login']!=111)
    {
        header("Location: home.php");  
    }else{
        $iUserID = $_SESSION['UserID'];
    }

    if($_SESSION['login']==111)
    {
        if(isset($_SESSION['UserID'])){$iUserID = $_SESSION['UserID'];}
        if(isset($_SESSION['firstname'])){$sFirstname = $_SESSION['firstname'];}
        if(isset($_SESSION['lastname'])){$sLastname = $_SESSION['lastname'];}
    }


    if (isset($_POST['firstname'])) 
	{
		$sFirstname=$_POST['firstname'];
	}
    if (isset($_POST['lastname'])) 
	{
		$sLastname=$_POST['lastname'];
	}
    if (isset($_POST['currentPassword'])) 
	{
		$sCurrentPassword=$_POST['currentPassword'];
	}
    if (isset($_POST['newPassword'])) 
	{
		$sNewPassword=$_POST['newPassword'];
	}
    if (isset($_POST['newPasswordConfirm'])) 
	{
		$sNewPasswordConfirm=$_POST['newPasswordConfirm'];
	}

    echo($sFirstname);
    echo($sCurrentPassword);
    echo(var_dump($_POST));
include 'dbsettings.php';
$conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "SELECT * FROM user WHERE UserID='".$iUserID."'" ;
        $result = $conn->query($sql);

    foreach ($result as $row) 
    {
        $sPasswordDatabaseHash=$row['Password'];
    
        
    if(password_verify($sCurrentPassword, $sPasswordDatabaseHash)) {
        if($sNewPassword==$sNewPasswordConfirm) {
            $hashed_password = password_hash($sNewPassword, PASSWORD_BCRYPT);
            $sql = "UPDATE User SET firstname = :value1 , lastname = :value2 , Password = :value3 WHERE UserID = :value4";
            $stmt = $conn->prepare($sql);
            $stmt->bindValue(':value1', $sFirstname);
            $stmt->bindValue(':value2', $sLastname);
            $stmt->bindValue(':value3', $hashed_password);
            $stmt->bindValue(':value4', $iUserID);
            $stmt->execute();
            echo "alert(Your profile has been updated!)";


        }
    } else {
        echo "alert(Your profile could not be updated!)";
    }

}
header("Location: profile.php");

?>