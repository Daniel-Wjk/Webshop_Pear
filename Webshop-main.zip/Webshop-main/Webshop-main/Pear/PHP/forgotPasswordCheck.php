<?php
if (isset($_POST['emailforgotpassword'])) 
{
    $sUserID=$_POST['emailforgotpassword'];
}
include 'generatePassword.php';
include 'dbsettings.php';
$conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "SELECT * FROM user WHERE email='".$sUserID."'" ;
        $result = $conn->query($sql);
        //echo($result);
        foreach ($result as $row) 
        {
            $sFirstName=$row['firstname'];
            echo($sFirstName);
            $sLastName=$row['lastname'];
        }
        $random = generateRandomPassword(10);
        $password = 'IAmStupid'.$random;
        

        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $sql = "UPDATE user SET Password = :value1 , LoginStatus = 2  WHERE email = :value2";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':value1', $hashed_password);
        $stmt->bindValue(':value2', $sUserID);
        $stmt->execute();

//$hashedPassword = password_hash("IAmStupid!1!1!", PASSWORD_BCRYPT); 
//$sql = "UPDATE User SET Password = '".$hashedPassword."' WHERE UserID = '".$sUserID."'";
include 'sendForgotPassword.php';
sendForgotPasswordEmail($sUserID, $sLastName, $sFirstName, $password);
header("Location: login.php");
?>
