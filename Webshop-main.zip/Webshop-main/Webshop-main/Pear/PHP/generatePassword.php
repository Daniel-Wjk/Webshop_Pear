<?php
function generateRandomPassword($length = 8) {
    // Define character sets
    $lowercase = 'abcdefghijklmnopqrstuvwxyz';
    $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $numbers = '0123456789';
    $symbols = '!@#$%^&*()-_=+,.?';

    // Combine all character sets
    $characters = $lowercase . $uppercase . $numbers . $symbols;

    // Get the total number of characters
    $characterCount = strlen($characters);

    // Initialize the password variable
    $password = '';

    // Generate random password
    for ($i = 0; $i < $length; $i++) {
        $randomIndex = mt_rand(0, $characterCount - 1);
        $password .= $characters[$randomIndex];
    }

    return $password;
}
?>