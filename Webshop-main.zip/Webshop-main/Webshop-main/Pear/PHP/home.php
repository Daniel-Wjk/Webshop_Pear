<?php
session_start();
if(isset($_SESSION['login'])){
if($_SESSION['login']==111)
    {
        if(isset($_SESSION['UserID'])){$iUserID = $_SESSION['UserID'];}
    
    }}else{$_SESSION['login'] = 000;}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include 'headimport.php';
    ?>
    <title>Pear</title>
</head>

<body class="m-0 border-0 bd-example" id="bd">


    <?php
        include 'navimport.php';
    ?>


    <img src="../IMGS/indexad.png" class="w-100 container d-flex" alt="">

    <div class="container color3">
        <div id="carouselExampleCaptions" class="carousel slide " data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                    aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                    aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active m-5" style="height: 500px; position: relative;">
                    <img src="../IMGS/iphone14pro.jpg" class="d-block" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); " alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <form action="product_page.php" method="POST">
                            <input type="hidden" name="ProductID" value="1">
                            <button type="submit" class="btn btn-primary">IPhone 14 Pro</button>
                        </form>
                    </div>

                </div>
                <div class="carousel-item m-5" style="height: 500px; position: relative;">
                    <img src="../IMGS/iphone14.jpg" class="d-block " style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); " alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <form action="product_page.php" method="POST">
                            <input type="hidden" name="ProductID" value="2">
                            <button type="submit" class="btn btn-primary">IPhone 14</button>
                        </form>
                    </div>

                </div>
                <div class="carousel-item m-5" style="height: 500px; position: relative;">
                    <img src="../IMGS/iphone13.jpg" class="d-block" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); " alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <form action="product_page.php" method="POST">
                            <input type="hidden" name="ProductID" value="3">
                            <button type="submit" class="btn btn-primary">IPhone 13</button>
                        </form>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon bg-primary" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="next">
                <span class="carousel-control-next-icon bg-primary" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

    </div>
    <?php
        include 'footimport.php';
    ?>
</body>

</html>