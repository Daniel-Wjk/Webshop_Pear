<?php
    $sql = "SELECT numOnline FROM userOnline Where ID = 0";
    $result = $conn->query($sql);

    echo "<p>";
    echo $result;
    echo "</p>";
?>