
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php
    include 'headimport.php';
    ?>
    <script>
        // Function to update the hidden input field with screen resolution
        function updateResolutionInput() {
            var screenWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
            var screenHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
            
            var resolution = screenWidth + "x" + screenHeight;
            
            // Update the hidden input field value
            $("#resolutionInput").val(resolution);
        }
        
        // Call the function to update the hidden input field
        window.onload = function() {
            updateResolutionInput();
        };
    </script>
  <title>Document</title>
</head>

<body class="p-3 m-0 border-0 bd-example " id="bd">
  <div class="container">
    <div class="row">
      <br><br>
    </div>
    <div class="row">

      <div class="col"></div>
      <div class="col color2 rounded">
        <div class="text-center mt-3">
          
          <h3>LOGIN</h3> <img src="../IMGS/user-gdb454317d_1280.png" class="rounded w-25" alt="...">
        </div>

        <form method="POST" class="mx-1" action="logincheck.php">
          <div class="mb-3">
            <label for="Email" class="form-label">Email address</label>
            <input type="email" class="form-control" id="Email" name="email" value="">
            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
          </div>
          <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" value="">
          </div>
          <div class="mb-3">
            <label for="g2fa" class="form-label">Google 2 FA Code</label>
            <input type="text" class="form-control" id="g2fa" name="g2fa" value="">
          </div>
          <input type="hidden" id="resolutionInput" name="resolution">
          <button type="submit" class="btn btn-primary mb-2">Login</button>
        </form>
        <a class="mx-1 " href="forgotPassword.php">Forgot Password?</a>
        <br><br>

        <p class="mb-3" id="hiddentext">Username requieres "@" and atleast 5 characters.</p>

        <a href="registration.php" class="mb-2 mx-1 btn btn-primary ">NEW? Register NOW!</a>
      </div>
      <div class="col"></div>
    </div>

  </div>

  <script>
    $(document).ready(function()
        {
            setInterval(function()
            {
                /*if((($_POST['username'] !== NULL) && (str_contains($_POST['username'], "@"))))*/
                if(document.getElementById("Email").value.includes("@") && document.getElementById("Email").length>=5) {
                    document.getElementById("hiddentext").style.visibility="hidden";
                } else {
                    document.getElementById("hiddentext").style.visibility="visible";
                };
            },1000);
        });
  </script>

</body>

</html>
