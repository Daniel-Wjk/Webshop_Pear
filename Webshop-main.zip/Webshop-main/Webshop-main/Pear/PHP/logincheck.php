<?php
    echo var_dump($_POST);;
    $sEmail="";
    $sPassword="";
    $sG2fa="";
    $Resolution="";
    $sPasswordDatabaseHash="";
    $checkResult=false;
    $iUserID="";

    if(isset($_POST['email']))
    {
        $sEmail=$_POST['email'];
    }
    if(isset($_POST['password']))
    {
        $sPassword=$_POST['password'];
    }
    if(isset($_POST['resolution']))
    {
        $Resolution=$_POST['resolution'];
    }
    if(isset($_POST['g2fa']))
    {
        $sG2fa=$_POST['g2fa'];
        
    
        
    }
    if($sEmail!=="" && $sEmail!=="")
    {
        include 'dbsettings.php';
        $conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "SELECT * FROM user WHERE email='".$sEmail."'" ;
        $result = $conn->query($sql);

        
        foreach ($result as $row) 
        {
            //echo $row['Password'];
            $sPasswordDatabaseHash=$row['Password'];
            $sG2faDatenbankSecret=$row['Google2FSecret'];
            $iLoginStatus=$row['LoginStatus'];
            //echo($sPasswordDatabaseHash);
            //echo($sG2faDatenbankSecret);
            //echo($sG2fa);
            //echo($sG2faDatenbankSecret);
            if(password_verify($sPassword, $sPasswordDatabaseHash)){
                require_once '../extern/google_auth/PHPGangsta/GoogleAuthenticator.php';
                $ga = new PHPGangsta_GoogleAuthenticator();
                $checkResult = $ga->verifyCode($sG2faDatenbankSecret, $sG2fa, 2);
                /*if ($checkResult) {
                    echo 'OK';
                } else {
                    echo 'FAILED';
                } */
                //$checkResult = true;
                if($checkResult){
                    echo($sPassword);
                // PHP Session starten!
                session_start();
                $_SESSION['UserID']=$row['UserID'];
                $_SESSION['firstname']=$row['firstname'];
                $_SESSION['lastname']=$row['lastname'];
                $_SESSION['email']=$row['email'];
                $_SESSION['login']=111;
                $_SESSION['time']=time();
                $_SESSION['LoginStatus']=$row['LoginStatus'];
                $iUserID=$_SESSION['UserID'];
                }
                
            }
            
            
        }
        
        if($checkResult)
        {
        $sql = "UPDATE User SET  Resolution = :value2, OnlineStatus = 1 WHERE UserID = :value3";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':value2', $Resolution);
        $stmt->bindValue(':value3', $iUserID);
        $stmt->execute();
        $numOn = 0;
        // userOnline um 1 erhöhen
        $sql = "SELECT * FROM userOnline WHERE ID=0";
        $result = $conn->query($sql);
        foreach($result as $row){
            $numOn=$row['numOnline'];
        }
        $numOn = $numOn + 1;
        $sql_1 = "UPDATE userOnline SET numOnline = :value1 WHERE ID=0";
        $stmt = $conn->prepare($sql_1);
        $stmt->bindValue(':value1', $numOn);
        $stmt->execute();
        if($iLoginStatus==0) {
            header("Location: firstLogin.php");
        } else if ($iLoginStatus==1) {
            header("Location: profile.php");
        } else {
            header("Location: forgotPasswordLogin.php");
        }
        echo "success";
        }
        else
        {
        header("Location: login.php");
        echo "NOOOO success";
        }
    }
    
 
?>