<?php

    // Initialisierung der Session.
  // Wenn Sie session_name("irgendwas") verwenden, vergessen Sie es
  // jetzt nicht!
  session_start();
  if(!isset($_SESSION['UserID'])){
    $UserID = $_SESSION['UserID'];}
  // Löschen aller Session-Variablen.
  $_SESSION = array();

  // Falls die Session gelöscht werden soll, löschen Sie auch das
  // Session-Cookie.
  // Achtung: Damit wird die Session gelöscht, nicht nur die Session-Daten!
  if (ini_get("session.use_cookies")) {
      $params = session_get_cookie_params();
      setcookie(session_name(), '', time() - 42000, $params["path"],
          $params["domain"], $params["secure"], $params["httponly"]
      );
  }

  // Zum Schluß, löschen der Session.
  session_destroy();

// userOnline um 1 verringern
include 'dbsettings.php';
$conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "SELECT * FROM userOnline WHERE ID=0";
        $result = $conn->query($sql);
        foreach($result as $row){
            $numOn=$row['numOnline'];
        }
        $numOn = $numOn - 1;
        $sql_1 = "UPDATE user SET LastOnline = CURRENT_TIMESTAMP , OnlineStatus = 0 Where UserID = ".$UserID;
        $stmt = $conn->prepare($sql_1);
        $stmt->bindValue(':value1', $numOn);
        $stmt->execute();
        $sql_1 = "UPDATE userOnline SET  numOnline = :value1 Where ID = 0";
        $stmt = $conn->prepare($sql_1);
        $stmt->bindValue(':value1', $numOn);
        $stmt->execute();

    header("Location: home.php");
?>
