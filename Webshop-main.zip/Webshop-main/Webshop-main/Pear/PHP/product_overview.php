<?php
session_start();
if(isset($_SESSION['login'])){
if($_SESSION['login']==111)
    {
        if(isset($_SESSION['UserID'])){$iUserID = $_SESSION['UserID'];}
    
    }}else{$_SESSION['login'] = 000;}
    $sSortMethod="";
    $sKeyWords="";

    if(isset($_POST['SortMethod']))
    {
        $sSortMethod=$_POST['SortMethod'];
        //echo $_POST['SortMethod'];
    }
    
    if(isset($_POST['SortedBy']))
    {
        $sKeyWords =  $_POST['SortedBy'];
        //echo $_POST['SortedBy'];
    }
    if(isset($_POST['SearchString']))
    {
        $sKeyWords =  $_POST['SearchString'];
        //echo $_POST['SearchString'];
    }
    else{
        //echo "Is not set!";
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include 'headimport.php';
    ?>
    <title>
        <?php
        echo $sKeyWords;
        ?>
    </title>
</head>

<body class="m-0 border-0 bd-example" id="bd">
    
    <?php
        include 'navimport.php';
    ?>

    <div class="container color1  align-items-center">
        <div class="row"><br></div>
        <!-- form muss zu suchalgo programmiert werden -->
        <form class=" d-flex" action="product_overview.php" method="post">
            <input type="hidden" name="SortMethod" value="SEARCH">
            <input class="form-control me-2" type="text" placeholder="Search" name="SearchString">
            <button class="btn btn-primary" type="submit">Search</button>

        </form>
        <div class="row"><br></div>
    </div>
    
    
    <div class="container color2 d-flex align-items-center">
        <br>
        <div class="row d-flex justify-content-center mt-3 gap-3 ">
        <?php

    //echo var_dump($_POST);

    

    
    

    include 'dbsettings.php';
    $conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (strcmp($sSortMethod, 'TYP') == 0) {
        if(strcmp($sKeyWords, 'ALL Products') == 0 )
        {
            $sql="SELECT * FROM product" ;
        //echo $sql;
        $ergebnis =  $conn->query($sql);
       // echo $ergebnis;
        foreach($ergebnis as $row){
            $iProductID = $row['ProductID'];
            $sName = $row['Name'];
            $sIMGSrc = $row['Img'];
            $sDiscription = $row['ProductDescription'];
            $fPrice = $row['Price'];

           echo '<div class="card w-25 text-center mb-3" >
           <img src="../IMGS/'.$sIMGSrc.'" class="card-img-top rounded float-start " alt="...">

           <div class="card-body" >
               <h5 class="card-title">'.$sName.'</h5>
               <p class="card-text">'.$sDiscription.'</p>
               <p class="card-text">'.$fPrice.' €</p>
               <form action="product_page.php" method="post"><input type="hidden" name="ProductID" value="'.$iProductID.'"><button class="btn btn-primary" type="submit">Check it out Now!</button></form>
           </div>
       </div>';
        }}
        else{
        $sql="SELECT * FROM product WHERE TYP = '".$sKeyWords."'" ;
        //echo $sql;
        $ergebnis =  $conn->query($sql);
       // echo $ergebnis;
        foreach($ergebnis as $row){
            $iProductID = $row['ProductID'];
            $sName = $row['Name'];
            $sIMGSrc = $row['Img'];
            $sDiscription = $row['ProductDescription'];
            $fPrice = $row['Price'];

           echo '<div class="card w-25 text-center mb-3">
           <img src="../IMGS/'.$sIMGSrc.'" class="card-img-top rounded float-start " alt="...">

           <div class="card-body" >
               <h5 class="card-title">'.$sName.'</h5>
               <p class="card-text">'.$sDiscription.'</p>
               <p class="card-text">'.$fPrice.' €</p>
               <form action="product_page.php" method="post"><input type="hidden" name="ProductID" value="'.$iProductID.'"><button class="btn btn-primary" type="submit">Check it out Now!</button></form>
           </div>
       </div>';
        }
        }
    }
    if (strcmp($sSortMethod, 'SEARCH') == 0) {
        
        $sql="SELECT * FROM product WHERE Name LIKE '%".$sKeyWords."%'" ;
        //echo $sql;
        $ergebnis =  $conn->query($sql);
       // echo $ergebnis;
        foreach($ergebnis as $row){
            $iProductID = $row['ProductID'];
            $sName = $row['Name'];
            $sIMGSrc = $row['Img'];
            $sDiscription = $row['ProductDescription'];
            $fPrice = $row['Price'];

           echo '<div class="card w-25 text-center mb-3" >
           <img src="../IMGS/'.$sIMGSrc.'" class="card-img-top rounded float-start " alt="...">

           <div class="card-body" >
               <h5 class="card-title">'.$sName.'</h5>
               <p class="card-text">'.$sDiscription.'</p>
               <p class="card-text">'.$fPrice.' €</p>
               <form action="product_page.php" method="post"><input type="hidden" name="ProductID" value="'.$iProductID.'"><button class="btn btn-primary" type="submit">Check it out Now!</button></form>
           </div>
       </div>';
        }
        
        
    }
    
?>
        </div>
        
    </div>
    <?php
        include 'footimport.php';
    ?>
</body>

</html>