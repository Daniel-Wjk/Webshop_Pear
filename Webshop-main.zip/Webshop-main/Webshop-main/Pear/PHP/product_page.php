<?php
session_start();
if(isset($_SESSION['login'])){
if($_SESSION['login']==111)
    {
        if(isset($_SESSION['UserID'])){$iUserID = $_SESSION['UserID'];}
    
    }}else{$_SESSION['login'] = 000;}

      $iProductID="";


      if(isset($_POST['ProductID']))
      {
          $iProductID=$_POST['ProductID'];
         // echo $iProductID;
      }
      if(isset($_GET['ProductID']))
      {
          $iProductID=$_GET['ProductID'];
         // echo $iProductID;
      }
      ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include 'headimport.php';
    ?>
    <title>
    
    <?php
      include 'dbsettings.php';
      $conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      
      
          $sql="SELECT * FROM product WHERE ProductID = ".$iProductID."" ;
          //echo $sql;
          $ergebnis =  $conn->query($sql);
         // echo $ergebnis;
         $sName ="";
          foreach($ergebnis as $row){
              $sName = $row['Name'];
          }
          echo $sName;
    ?>
    </title>
</head>
<body class="m-0 border-0 bd-example" id="bd">

    <?php
        include 'navimport.php';
    ?>
    <div class="container color1  align-items-center">
        <div class="row"><br></div>
        <!-- form muss zu suchalgo programmiert werden -->
        <form class=" d-flex mx-5" role="search">

            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-primary" type="submit">Search</button>

        </form>
        <div class="row"><br></div>
    </div>
    <div class="container color2 d-flex justify-content-center align-items-center">

        <div class="card m-5" style="max-width: 100%;">
            <div class="row g-0">
            <?php

//echo var_dump($_POST);




include 'dbsettings.php';
$conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    $sql="SELECT * FROM product WHERE ProductID = ".$iProductID."" ;
    //echo $sql;
    $ergebnis =  $conn->query($sql);
   // echo $ergebnis;
    foreach($ergebnis as $row){
        $iProductID = $row['ProductID'];
        $sTYP = $row['TYP'];
        $sName = $row['Name'];
        $sIMGSrc = $row['Img'];
        $sDiscription = $row['ProductDescription'];
        $fPrice = $row['Price'];
        $sInformation = $row['ProductInfos'];

       echo '<div class="col-md-4">
            <img src="../IMGS/'.$sIMGSrc.'" class="img-fluid rounded-start" alt="...">
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title">'.$sName.'</h5>
              <br>
              <ul class="list-group">
                <li class="list-group-item">Price: '.$fPrice.' €</li>
                <li class="list-group-item">Product Type: '.$sTYP.'</li>
                <li class="list-group-item">Processor: '.$sInformation.'</li>
                
              </ul>
              <br>
              <p class="card-text">'.$sDiscription.'</p>
              ';

              if($_SESSION['login']==111){

              $Amount = "";

              $sql2="SELECT COUNT(*) as a FROM Shoppingcart WHERE UserID = ".$iUserID." AND ProductID = ".$iProductID;
              $Ergebnis2 = $conn->query($sql2);

              $sql1="SELECT * FROM Shoppingcart WHERE UserID = ".$iUserID." AND ProductID = ".$iProductID;
              $Ergebnis1 = $conn->query($sql1);

              foreach($Ergebnis1 as $row){
                $Amount = $row['Amount'];
              }

              foreach($Ergebnis2 as $row){
                    $checkShoppingCart = $row['a'];
                    if($checkShoppingCart == 0){
                            echo '<form action="addToShoppingcart.php" method="Post"> <input type="hidden" name="ProductID" value="'.$iProductID.'"><input type="hidden" name="returnTo" value="product_page.php"> <button type="submit" ID="addToShoppincart" class="btn btn-primary">Add to Shoppingcart</button></form>' ;
                }elseif($checkShoppingCart == 1){
                   echo 'Currently in Shoppincart: <br><div class = "row d-flex flex-row">
                   <form action="reduceAmount.php" method="Post"> <input type="hidden" name="ProductID" value="'.$iProductID.'"><input type="hidden" name="returnTo" value="product_page.php"> <button class="btn btn-primary" type="submit" ID="reduceAmount">-</button></form> '.$Amount.' <form action="increaseAmount.php" method="Post"> <input type="hidden" name="ProductID" value="'.$iProductID.'"><input type="hidden" name="returnTo" value="product_page.php"><button class="btn btn-primary" type="submit" ID="increaseAmount">+</button></form></div> ';
               }
              }
            }else{
               echo 'You are Currently not Logged in. Pleas Register or Login to Buy out Products! <br> 
                     <a href="login.php">Login</a> <br> <a href="registration.php">Registration</a>';
            }
              echo'
            </div>
          </div>
       ';   
    }
?>
            </div>
          </div>
        
    </div>
<script>
  var data = {
  ProductID: <?php echo $iProductID ?>,
  Amount: <?php echo $Amount ?>
};
  $( "#addToShoppingcart").on("click", function() {
    $.post(addToShoppincart.php,data);
    location.reload();
} );
$( "#reduceAmount").on("click", function() {
    $.load(reduceAmount.php,data);
    location.reload();
} );
$( "#increaseAmount").on("click", function() {
    $.load(increaseAmount.php,data);
    location.reload();
} );
</script>
<?php
        include 'footimport.php';
    ?>
</body>
</html>