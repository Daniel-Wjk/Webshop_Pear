<?php
session_start();
if(!isset($_SESSION['login'])){
    $_SESSION['login'] = 000;}
if($_SESSION['login']!=111)
    {
        header("Location: home.php");  
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include 'headimport.php';
    ?>
    <title>Document</title>
</head>

<body class="m-0 border-0 bd-example " id="bd">

    <?php
        include 'navimport.php';
    ?>
    <div class="container color1 d-flex justify-content-center">
        <div class="card m-5">
            <div class="card-body">
                <h1>Finish your Purchase!</h1>
                <h5 class="my-3">
                <?php
                if(isset($_POST['TotalCost']))
                {
                    $TotalCost=$_POST['TotalCost'];
                }
                ?>
                    Total Price: <?php echo($TotalCost); ?> €
                </h5>
                
                <form action="purchaseCheck.php" method="POST">
                    <p>Adress:</p>
                    <div class="mb-3">
                        <label for="city" class="form-label">City</label>
                        <input type="text" id="city" class="form-control" placeholder="Example City">
                    </div>
                    <div class="mb-3">
                        <label for="zip" class="form-label">ZIP Code</label>
                        <input type="text" id="zip" class="form-control" placeholder="Example zip">
                    </div>
                    <div class="mb-3">
                        <label for="streetAndNumber" class="form-label">Street and Nr</label>
                        <input type="text" id="streetAndNumber" class="form-control" placeholder="Example Street 13">
                    </div>
                    <br>
                    <p>Payment:</p>
                    <div class="mb-3">
                        <label for="iban" class="form-label">IBAN</label>
                        <input type="text" id="iban" class="form-control" placeholder="Example IBAN">
                    </div>
                    <div class="mb-3">
                        <input type="radio" name="versand" value="DPD">
                        <label for="DPD">DPD +5€</label>
                        <input type="radio" name="versand" value="DHL">
                        <label for="DHL">DHL +10€</label>
                        <input type="radio" name="versand" value="DHL Express">
                        <label for="DHL Express">DHL Express +24€</label>
                    </div>
                    <div>
                        <input type="checkbox" name="Datenschutz" value="Datenschutz">
                        <label for="Datenschutz">I accept the privacy policy.</label>
                    </div>
                    <div>
                        <input type="text" name="promo" value="promo">
                        <label for="promo">promocode:</label>
                    </div><input type="hidden" name="TotalCost" value=<?php echo($TotalCost); ?>>
                    <button id="confirmPurchase" type="Submit" class="btn btn-primary" >Confirm</button>
                </form>
            </div>
        </div>

    </div>
    <script>
        $('#confirmPurchase').on('click',function(){
            Swal.fire( 'Great, Your Purchase is finished', 'Please check your emails for the recipt.', 'success' );
        })
    </script>
    <?php
        include 'footimport.php';
    ?>
</body>

</html>