<?php
    include 'generatePassword.php';

    if (isset($_POST['email'])) 
	{
		$sEmail=$_POST['username'];
	}

    $conn = new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $password = generateRandomPassword(10);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $sql = "UPDATE user SET password=$hashed_password WHERE email=$sEmail";
    $conn->query($sql);;

    $mailMessage = 'Hello '.$sFirstName.' '.$sLastName.', \n your new password is '.$password;

    include ' ..\vendor\phpmailer\phpmailer\examples\gmail_xoauth.php';
?>