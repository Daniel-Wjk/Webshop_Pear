<?php

//Load Composer's autoloader
//require_once __DIR__ . ('/../../vendor/autoload.php');



//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/phpmailer/src/Exception.php';
require 'phpmailer/phpmailer/src/PHPMailer.php';
require 'phpmailer/phpmailer/src/SMTP.php';

//Load Composer's autoloader
//require 'vendor/autoload.php';

//Create an instance; passing `true` enables exceptions

function sendOrderEmail($sUsername, $sLastname, $sFirstname, $iOrderID, $versand, $finalPrice) {
$mail = new PHPMailer(true);

try {
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'saitejamucherla@gmail.com';                     //SMTP username
    $mail->Password   = 'spcv jzqg ngny nmhx';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('saitejamucherla@gmail.com', "Pear");
    $mail->addAddress($sUsername, ''.$sFirstname." ".$sLastname);     //Add a recipient

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Order'.$iOrderID;
        $Body1    = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>The Real Pear - Order '.$iOrderID.'</title>
            <style>
                body {
                    background-color: #f7f7f7;
                    font-family: Arial, sans-serif;
                    text-align: center;
                }
        
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                    background-color: #ffffff;
                    border-radius: 10px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    text-align: center;
                }
        
                h1 {
                    font-size: 28px;
                    margin-top: 0;
                }
        
                p {
                    font-size: 16px;
                    line-height: 1.5;
                    margin-bottom: 20px;
                }
        
                button {
                    background-color: #0070c9;
                    color: #ffffff;
                    padding: 10px 20px;
                    border: none;
                    border-radius: 5px;
                    font-size: 16px;
                    cursor: pointer;
                    transition: background-color 0.3s ease;
                }
        
                button:hover {
                    background-color: #004c8e;
                }
        
                .footer {
                    font-size: 14px;
                    color: #999999;
                    margin-top: 20px;
                }
                
                header {
                    background: linear-gradient(to right, #0F8EC0, #58D3F0);
                    color: white;
                    padding: 20px;
                    text-align: center;
                }
                
                h1 {
                    margin: 0;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <header>
                    <h1>The Real Pear</h1>
                </header>
                <h2>Hey ' . $sFirstname . '! Your Order was sucessful!</h2>
                <p>This is your Order List:</p><br>';

                $Body2 = '<div>
                            <table>
                            <thead>
                                Order Nr: '.$iOrderID.' | 
                                Shipping Option: '.$versand. '
                            </thead>
                            <thead>
                                <tr>
                                    <th >Product Name</th>
                                    <th >Amount</th>
                                    <th >Product ID</th>
                                    <th >Cost</th>
                                </tr>
                            </thead> 
                            <tbody>';
                            $Body3 = "";
                        include 'dbsettings.php';
                        $conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
                        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                
                        $sql = "SELECT * FROM `Order` WHERE OrderID = :iOrderID";
                        $stmt = $conn->prepare($sql);
                        $stmt->bindValue(':iOrderID', $iOrderID);
                        $stmt->execute();
                        foreach($stmt as $row) {
                            $iProductID = $row['ProductID'];
                            $productPrice = $row['finalSum'];
                            $sql = "SELECT * FROM `Product` WHERE productID = :productID";
                            $stmt_product = $conn->prepare($sql);
                            $stmt_product->bindValue(':productID', $iProductID);
                            $stmt_product->execute();
                        
                            $productName = "";
                            
                            foreach($stmt_product as $product_row) {
                                $productName = $product_row['Name'];
                            }
                        
                            $iAmount = $row['Amount'];
                        
                            $Body3  = $Body3. '
                                    <tr>
                                        <th>'.$productName.'</th>
                                        <td>'.$iAmount.'</td>
                                        <td>'.$iProductID.'</td>
                                        <td>'.$productPrice.' €</td>
                                    </tr>
                            ';
                        }

                $Body4 = '
                <tr>
                                        <th>Shipping: </th>
                                        <td>'.$versand.'</td>';
                $versandPreis = "";
                if($versand=="DPD") {
                    $versandPreis = 5;
                } elseif($versand=="DHL") {
                    $versandPreis = 10;
                } elseif($versand=="DHL Express") {
                    $versandPreis = 24;
                }
                $Body5 = '<td>'.$versandPreis.' €</td>';
                $Body6 = '</tr>
                <tr>
                                        <th>Total Price: </th>
                                        <td>'.$finalPrice.' €</td>
                </tr>
                </tbody>
                <p>Thank you for your purchase!</p>
                <div class="footer">
                    <p>This email was sent to ' . $sUsername . '. If you have any questions, please contact our customer support.</p>
                    <p>Pear, Pearstreet 150, 165129 Pear City, USA</p>
                </div>
            </div>
        </body>
        </html>
        
';
$MailBody = ''.$Body1.$Body2.$Body3.$Body4.$Body5.$Body6;
$mail->Body    = $MailBody;

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
}
