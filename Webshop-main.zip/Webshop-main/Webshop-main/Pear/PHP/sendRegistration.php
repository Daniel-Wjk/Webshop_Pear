<?php

//Load Composer's autoloader
//require_once __DIR__ . ('/../../vendor/autoload.php');



//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/phpmailer/src/Exception.php';
require 'phpmailer/phpmailer/src/PHPMailer.php';
require 'phpmailer/phpmailer/src/SMTP.php';

//Load Composer's autoloader
//require 'vendor/autoload.php';

//Create an instance; passing `true` enables exceptions

function sendRegistrationEmail($sUsername, $sLastname, $password, $sFirstname, $secret) {
$mail = new PHPMailer(true);

try {
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'saitejamucherla@gmail.com';                     //SMTP username
    $mail->Password   = 'spcv jzqg ngny nmhx';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('saitejamucherla@gmail.com', "Pear");
    $mail->addAddress($sUsername, ''.$sFirstname." ".$sLastname);     //Add a recipient

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Registration';
        require_once '../extern/google_auth/PHPGangsta/GoogleAuthenticator.php';
            $ga = new PHPGangsta_GoogleAuthenticator();
            $qrCodeUrlBlob2 = $ga->getQRCodeGoogleUrl('Blog', $secret);

            $secretQR =  "<img style='display: block;-webkit-user-select: none;margin: auto;background-color: hsl(0, 0%, 90%);transition: background-color 300ms;' src='https://api.qrserver.com/v1/create-qr-code/?data=otpauth%3A%2F%2Ftotp%2FBlog%3Fsecret%3D".$secret."&amp;size=200x200&amp;ecc=M'>";
        $mail->Body    = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>The Real Pear - Registration</title>
            <style>
                body {
                    background-color: #f7f7f7;
                    font-family: Arial, sans-serif;
                    text-align: center;
                }
        
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                    background-color: #ffffff;
                    border-radius: 10px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    text-align: center;
                }
        
                h1 {
                    font-size: 28px;
                    margin-top: 0;
                }
        
                p {
                    font-size: 16px;
                    line-height: 1.5;
                    margin-bottom: 20px;
                }
        
                button {
                    background-color: #0070c9;
                    color: #ffffff;
                    padding: 10px 20px;
                    border: none;
                    border-radius: 5px;
                    font-size: 16px;
                    cursor: pointer;
                    transition: background-color 0.3s ease;
                }
        
                button:hover {
                    background-color: #004c8e;
                }
        
                .footer {
                    font-size: 14px;
                    color: #999999;
                    margin-top: 20px;
                }
                
                header {
                    background: linear-gradient(to right, #0F8EC0, #58D3F0);
                    color: white;
                    padding: 20px;
                    text-align: center;
                }
                
                h1 {
                    margin: 0;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <header>
                    <h1>The Real Pear</h1>
                </header>
                <h2>Hey ' . $sFirstname . '! Your Registration was successful!</h2>
                <p>This is your one-time password:</p><br>
                <b>' . $password . '</b><br>
                <p>This is your Google 2FA Key:</p><br>
                <b>' . $secretQR . '</b><br>
                <p>Please finish your Registration by loging in!</p>
                <p>As a special welcome offer, use the promo code <b>promo10</b> for a $5 discount on your first order!</p>
                <small style="color: grey;">Please note that the minimum order total must be $20 or more to apply the discount.</small>
                <div class="footer">
                    <p>This email was sent to ' . $sUsername . '. If you have any questions, please contact our customer support.</p>
                    <p>Pear, Pearstreet 150, 165129 Pear City, USA</p>
                </div>
            </div>
        </body>
        </html>
        
';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
}

