<?php
session_start();
if(isset($_SESSION['login'])){
if($_SESSION['login']==111)
    {
        if(isset($_SESSION['UserID'])){$iUserID = $_SESSION['UserID'];}
    
    }}else{$_SESSION['login'] = 000;}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include 'headimport.php';
    ?>
    <title>Support</title>
</head>

<body class="m-0 border-0 bd-example" id="bd">

    <?php
        include 'navimport.php';
    ?>
    <div class="container d-flex justify-content-center mt-5">
        <div class="card">
            <div class="card-body">
                <h3>You have Trouble while using you Product or our shop?</h3>
                <p>No problem. Please Discribe the Problem so that it can be fixed quickly.</p>
                <form action="">
                <?php
                    
        
                    if(!$_SESSION['login']==111){
                        echo '
                    <div class="mb-3">
                        <label for="emailforsupport" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="emailforsupport" placeholder="name@example.com">
                    </div>';
                    }
                ?>
                    <div class="mb-3">
                        <label for="ProblemSupport" class="form-label">Please discribe the Problem.</label>
                        <textarea class="form-control" id="ProblemSupport" rows="3"></textarea>
                    </div>
                      <Button type="submit" class="btn btn-primary">Send Problem Request.</Button>
                </form>
                <br>
                <p>
                    You want to talk with us directly? Please contact us at: +XX XX XXX XXXXXX .
                </p>
            </div>
        </div>
    </div>
    <?php
        include 'footimport.php';
    ?>
</body>

</html>