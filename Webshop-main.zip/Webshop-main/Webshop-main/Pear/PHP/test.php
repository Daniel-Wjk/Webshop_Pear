<?php

include 'dbsettings.php';
$conn=new PDO("mysql:host=localhost;dbname=".$dbDatabasename,$dbLoginUsername,$dbPassword);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$Amount = "";

$sql2="SELECT COUNT(*) as a FROM Shoppingcart WHERE UserID = ".$iUserID." AND ProductID = ".$iProductID;
$Ergebnis2 = $conn->query($sql2);

$sql1="SELECT * FROM Shoppingcart WHERE UserID = ".$iUserID." AND ProductID = ".$iProductID;
$Ergebnis1 = $conn->query($sql1);

foreach($Ergebnis1 as $row){
  $Amount = $row['Amount'];
}

foreach($Ergebnis2 as $row){
  $checkShoppingCart = $row['a'];
  if($checkShoppingCart == 0){
    echo ' <button type="button" onclick="addToShoppincart('.$iProductID.')" class="btn btn-primary">Add to Shoppingcart</button>' ;
  }elseif($checkShoppingCart == 1){
    echo 'Currently in Shoppincart: <br>
          <button type="button" onclick="reduceAmount('..$iProductID')">-</button> '.$Amount.' <button type="button" onclick="increaseAmount('..$iProductID')">+</button> ';
  }
}
/**foreach($Ergebnis2 as $row){
    $fawe = $row['Amount'];
    if(gettype($fawe) != integer){
      echo "hi lappen";
    }
    //echo gettype($fawe);
}*/

?>