CREATE TABLE `userOnline`(
    `ID` int(10) NOT NULL,
    `numOnline` int(11) DEFAULT 0,
    PRIMARY KEY (`ID`)
)